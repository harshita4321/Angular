import { Component, Input, OnInit } from '@angular/core';
import { io } from 'socket.io-client'
import { ServiceCompService } from '../service-comp.service';

@Component({
  selector: 'app-chat-inbox',
  templateUrl: './chat-inbox.component.html',
  styleUrls: ['./chat-inbox.component.css']
})
export class ChatInboxComponent implements OnInit {
  SOCKET_ENDPOINT = 'http://localhost:3000';
  socket: any;
  message: string = '';
  username: string = ''
  info: string[] = []
  index: number = 0

  constructor(private compService: ServiceCompService) { }

  ngOnInit() {
    this.setupSocketConnection();
    this.compService.usernameSource.subscribe(msg => {
      this.username = msg
    })
  }

  setupSocketConnection() {
    this.socket = io('http://localhost:3000');
    this.socket.on('message-broadcast', (data: string[]) => {
      if (data) {
        const el1 = document.createElement('h4')
        el1.innerHTML = data[0]
        el1.style.fontSize = "22px"
        el1.style.color = "#0d822d"
        el1.style.fontStyle = 'italic'
        el1.style.fontFamily = "Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif"
        const el2 = document.createElement('label');
        el2.innerHTML = data[1]
        const el3 = document.createElement('img')
        el3.src = 'assets/star.jpg'
        el3.height = 20
        let compS = this.compService
        let star = false
        el3.addEventListener('click', (function () {
          if (star == false) {
            el3.src = '../assets/starred.jpg'
            compS.sendMessage(el2.innerHTML)
            star = true
          } else if (star == true) {
            el3.src = '../assets/star.jpg'
            compS.removeMessage(el2.innerHTML)
            star = false
          }
        }
        ))
        const el4 = document.createElement('p')
        let today = new Date()
        let hours = today.getHours()
        let min = today.getMinutes()
        let timeStamp = hours + ":" + min
        el4.innerHTML = timeStamp
        el4.style.fontSize = "12px"
        const element = document.createElement('li');
        element.style.background = 'white';
        element.style.padding = '15px 30px';
        element.style.margin = '10px';
        element.appendChild(el1)
        element.appendChild(el3)
        element.appendChild(el2)
        element.appendChild(el4)
        document.getElementById('message-list')?.appendChild(element);
        this.index = 1
      }
    });
  }

  SendMessage() {
    this.info.push(this.username)
    this.info.push(this.message)
    this.socket.emit('message', this.info);
    const el1 = document.createElement('h4')
    el1.innerHTML = this.info[0]
    el1.style.fontSize = "22px"
    el1.style.color = "#0d822d"
    el1.style.fontStyle = 'italic'
    el1.style.fontFamily = "Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif"
    const el2 = document.createElement('label');
    el2.innerHTML = this.info[1]
    el2.style.textAlign = 'right'
    const el3 = document.createElement('img')
    el3.src = '../assets/star.jpg'
    el3.height = 20
    let compS = this.compService
    let star = false
    el3.addEventListener('click', (function () {
      if (star == false) {
        el3.src = '../assets/starred.jpg'
        compS.sendMessage(el2.innerHTML)
        star = true
      } else if (star == true) {
        el3.src = '../assets/star.jpg'
        compS.removeMessage(el2.innerHTML)
        star = false
      }
    }
    ))
    const el4 = document.createElement('p')
    let today = new Date()
    let hours = today.getHours()
    let min = today.getMinutes()
    let timeStamp = hours + ":" + min
    el4.innerHTML = timeStamp
    el4.style.fontSize = "12px"
    const element = document.createElement('li');
    element.style.background = 'white';
    element.style.padding = '15px 30px';
    element.style.margin = '10px';
    element.style.textAlign = 'right';
    element.appendChild(el1)
    element.appendChild(el2)
    element.appendChild(el3)
    element.appendChild(el4)
    document.getElementById('message-list')?.appendChild(element);
    this.message = '';
    this.info = []
    this.index = 1
  }

}
