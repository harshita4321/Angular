import { FloatPipe } from './float.pipe';

describe('FloatPipe', () => {
  it('create an instance', () => {
    const pipe = new FloatPipe();
    expect(pipe).toBeTruthy();
  });
});
