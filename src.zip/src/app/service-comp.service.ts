import { Injectable } from '@angular/core';
import { BehaviorSubject, Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ServiceCompService {
  private msgSource=new Subject<string>()
  message$=this.msgSource.asObservable()

  private remMsgSource = new Subject<string>()
  remMessage$ = this.remMsgSource.asObservable()

  usernameSource = new BehaviorSubject<string>('')

  feedbackSource = new BehaviorSubject<boolean>(false)

  constructor() { }

  sendMessage(msg:string){
    this.msgSource.next(msg)
  }

  removeMessage(msg:string) {
    this.remMsgSource.next(msg)
  }

  // sendUsername(uname:string) {
  //   this.usernameSource.next(uname)
  //   console.log("service: ", this.usernameSource)
  // }

}
