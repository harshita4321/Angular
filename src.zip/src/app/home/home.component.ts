import { Component, OnInit } from '@angular/core';
import { ServiceCompService } from '../service-comp.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  subjectHead = "Miss. Devyani Kamble"

  constructor() { }

  ngOnInit(): void {
  }

}
