import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ChatInboxComponent } from './chat-inbox/chat-inbox.component';
import { ChatRoomsComponent } from './chat-rooms/chat-rooms.component';
import { HeaderComponent } from './header/header.component';
import { AboutComponent } from './about/about.component';
import { ChatsComponent } from './chats/chats.component';
import { HomeComponent } from './home/home.component';
import { FeedbackComponent } from './feedback/feedback.component';
import { FloatPipe } from './float.pipe';

@NgModule({
  declarations: [
    AppComponent,
    ChatInboxComponent,
    ChatRoomsComponent,
    HeaderComponent,
    AboutComponent,
    ChatsComponent,
    HomeComponent,
    FeedbackComponent,
    FloatPipe
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
