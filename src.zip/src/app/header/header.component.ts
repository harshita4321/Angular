import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { ServiceCompService } from '../service-comp.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  @Input() username=''

  constructor() { }

  ngOnInit(): void {
  }

}
