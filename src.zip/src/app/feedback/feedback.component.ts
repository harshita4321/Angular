import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { ServiceCompService } from '../service-comp.service';

@Component({
  selector: 'app-feedback',
  templateUrl: './feedback.component.html',
  styleUrls: ['./feedback.component.css']
})
export class FeedbackComponent implements OnInit {
  @Output() feedbackToParent = new EventEmitter()

  feedback=false

  constructor(private compService:ServiceCompService) { }

  ngOnInit(): void {
  }

  giveFeedback(){
    let el=document.getElementById('feedbackArea1')
    if(el!=null){
      el.innerHTML=''
    }
    this.feedback=true
  }

  submitFeedback(feedback:string){
    let el=document.getElementById("feedbackArea2")
    if(el!=null){
      el.innerHTML=''
    }
    this.feedbackToParent.emit(feedback)
    this.compService.feedbackSource.next(true)
  }


}
