import { Component, OnInit } from '@angular/core';
import { ServiceCompService } from '../service-comp.service';

@Component({
  selector: 'app-chat-rooms',
  templateUrl: './chat-rooms.component.html',
  styleUrls: ['./chat-rooms.component.css']
})
export class ChatRoomsComponent implements OnInit {
  username: string = ''
  starred_msg: string[] = []

  constructor(private compService: ServiceCompService) { }

  ngOnInit(): void {
    this.compService.message$.subscribe(msg => {
      this.starred_msg.push(msg)
    })
    this.compService.remMessage$.subscribe(msg => {
      let index = this.starred_msg.indexOf(msg)
      this.starred_msg.splice(index, 1)
    })
  }

}
