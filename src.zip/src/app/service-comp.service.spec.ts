import { TestBed } from '@angular/core/testing';

import { ServiceCompService } from './service-comp.service';

describe('ServiceCompService', () => {
  let service: ServiceCompService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ServiceCompService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
