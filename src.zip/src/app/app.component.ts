import { Component, OnInit } from '@angular/core';
import { ServiceCompService } from './service-comp.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'ChatApp';
  username = ''
  disabled = 'nav-link disabled'
  isDisabled = false
  isVisible = false
  rating = ''

  constructor(private compService: ServiceCompService) { }

  ngOnInit(): void {
    this.compService.feedbackSource.subscribe(msg => {
      this.isVisible = msg
    })
  }

  submit(str: string) {
    console.log("str:", str)
    if(str == null || str == '') {
      alert("Enter Your Name")
    }else {
      this.username = str
      console.log("app.ts: ", this.username)
      let el = document.getElementById('name')
      if (el != undefined) {
        el.innerHTML = ''
      }
      this.compService.usernameSource.next(this.username)
      this.disabled = 'nav-link'
      this.isDisabled = true
    }
  }

  showFeedback(feedback: string) {
    this.rating = " HAS GIVEN " + feedback + " STAR RATING!!"
  }

}
